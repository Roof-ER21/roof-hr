# mcp21

An OMJ 21 package. Gives any Express app an MCP server that acts **as the connected person**:
what a tool can read or write is exactly what that person can already do in the app, and on
top of that ceiling the person chooses scopes (area × read/write) when they mint a token.

Client-agnostic: Genie 21, Claude, ChatGPT, Cursor and anything else that speaks MCP over
Streamable HTTP with a bearer token connects the same way.

Pass one: bearer tokens minted in the host app, read scopes. Pass two: OAuth 2.1 with a consent
page, write scopes. Tool definitions do not change between the two passes.

## Who owns what

| The host app owns | mcp21 owns |
|---|---|
| users, tokens (stored as hashes), revocation, expiry | the Streamable HTTP transport (stateless, POST only) |
| resolving a bearer token to a person + scopes (`authenticate`) | scope enforcement (`area:read` / `area:write`, `*` wildcard) |
| the authorization inside every tool (`run` uses the app's own checks) | the tool registry, JSON Schema validation (ajv, draft-07, unknown properties refused) |
| where audit events go | result rendering, the audit event shape, data minimization |

## Install

```sh
npm install @omj21/mcp21
```

Node 20+. ESM only. Peer-free: it brings `@modelcontextprotocol/sdk` and `ajv` itself and
declares tool schemas as plain JSON Schema, so it does not care which zod your app uses.

## Express example

```ts
import express from "express";
import { createMcp21, hashToken, type Mcp21Tool } from "@omj21/mcp21";
import { db } from "./db.js";

const jobsList: Mcp21Tool = {
  name: "jobs_list",
  description: "List the jobs the connected person can see.",
  area: "jobs",
  access: "read",
  inputSchema: {
    type: "object",
    properties: { limit: { type: "integer", minimum: 1, maximum: 100 } },
  },
  async run(ctx, args) {
    // Route through the app's OWN authorization: the person, not the token, is the ceiling.
    const rows = await db.jobs.visibleTo(ctx.auth.principal.id, { limit: args.limit ?? 25 });
    return { json: { jobs: rows } };
  },
};

const mcp = createMcp21({
  name: "cc24",
  version: "1.0.0",
  tools: [jobsList],
  async authenticate(token) {
    const row = await db.mcpTokens.findByHash(hashToken(token));
    if (!row || row.revokedAt || row.expiresAt < new Date() || !row.user.active) return null;
    return {
      principal: { id: row.user.id, organizationId: row.user.orgId, label: row.user.name, role: row.user.role },
      scopes: row.scopes,        // e.g. ["jobs:read", "notes:read"]
      tokenId: row.id,
      readOnly: true,            // pass one: every token is read-only
    };
  },
  audit: (event) => db.mcpAudit.insert(event),
  disabled: () => process.env.MCP_DISABLED === "1",
});

const app = express();
app.use(express.json());              // before the mount; mcp21 reads the body itself otherwise
app.all("/mcp", (req, res) => void mcp.handler(req, res));
app.listen(3000);
```

Clients connect to `https://your-app/mcp` with `Authorization: Bearer <token>`. Verified with
the SDK's `Client` + `StreamableHTTPClientTransport` (that is how Genie 21 connects).

## HTTP behavior

| Situation | Response |
|---|---|
| `disabled()` returns true (checked first) | `503` `{ "error": "This MCP server is temporarily disabled." }` |
| no / malformed `Authorization: Bearer …` | `401` + `WWW-Authenticate: Bearer` |
| `authenticate()` returns `null` | `401` + `WWW-Authenticate: Bearer error="invalid_token"` |
| `authenticate()` throws | `500` with a generic message, never the stack |
| GET / DELETE / anything but POST | `405` + `Allow: POST` (no sessions in pass one) |
| body larger than `maxBodyBytes` (default 262144) when mcp21 reads it | `413` |
| body is not JSON | `400` |
| POST with a valid token | JSON-RPC via the MCP SDK, a fresh stateless server per request |

Every HTTP response above is a small JSON object with one `error` sentence.

## Scope grammar

```
scope  := area ":" access
area   := "*" | [a-z][a-z0-9_]*
access := "read" | "write"
```

- `jobs:read` unlocks every tool with `area: "jobs", access: "read"`.
- `*:read` unlocks every read tool. `*:write` every write tool.
- **`write` does not imply `read`.** Grant both when both are meant.
- `readOnly: true` on an auth hides and refuses every write tool regardless of scopes.

```ts
parseScopes(["jobs:read", "*:read"]);            // [{ area: "jobs", access: "read" }, { area: "*", access: "read" }]
parseScopes(["jobs:admin"]);                     // throws TypeError
scopeAllows(["jobs:write"], "jobs", "read");     // false
visibleTools(tools, auth);                       // what tools/list shows this auth
assertAreasCovered(["jobs", "notes"], tools);    // { missing: ["notes"] } when notes has no read tool
```

## Tool semantics

- `name` is snake_case and unique; `area` is snake_case (never `*`). The registry is validated
  when `createMcp21` runs, so a bad tool fails at boot, not at first call.
- `inputSchema` is JSON Schema draft-07 for an object. mcp21 forces
  `type: "object"` and `additionalProperties: false` on the copy it publishes and validates
  with. Unknown properties, wrong types, missing required arguments and bad enums come back as
  `isError: true` with one plain sentence (`Unknown argument "limt".`).
- Refusals are also tool results, never JSON-RPC errors: `There is no tool named "x".`,
  `This token has no jobs:read scope.`, `This token is read-only, so jobs_update is not available.`
- `run(context, args)` gets `{ auth, requestId, signal }`. `signal` aborts when the client
  disconnects or cancels. A thrown error becomes `The jobs_list tool failed.` for the client;
  the real message goes to the audit event only.
- Results: `text` → one text block; `json` → a `JSON.stringify` text block and, for a plain
  object, `structuredContent` too; both may be present; `isError` passes through.

## Token helpers

```ts
const { token, hash, hint } = generateToken("cc24");
// token: "cc24_" + 32 random bytes in base62  (show once, never store)
// hash:  sha256 hex of the whole token          (store this)
// hint:  last 4 chars                            (display: "…k9Qz")
hashToken(token) === hash;                        // true, and what authenticate() looks up
```

## Audit event

One per `tools/call`, whether it succeeded, was refused, was invalid or threw.

```ts
type Mcp21AuditEvent = {
  at: Date;
  requestId: string;          // random UUID per HTTP request
  tokenId: string;
  principalId: string;        // the ONLY principal field that reaches audit
  tool: string;
  area: string;               // "unknown" when the tool does not exist
  access: "read" | "write";
  argumentKeys: readonly string[];   // keys only, never values
  ok: boolean;
  error?: string;             // "unknown tool" | "read-only token" | "missing scope jobs:read"
                              // | "invalid arguments: …" | the thrown error's message
  durationMs: number;
};
```

`audit` is awaited; if it throws, the call still succeeds and the failure is printed to
`console.error` once per process.

## What the host app must do

- Store `hashToken(token)`, never the token. Show the token once at mint; keep `hint` for the UI.
- In `authenticate`: look up by hash, then check **revoked**, **expired** and **user still
  active** before returning an auth. Return `null` for anything doubtful.
- Route every tool's `run` through the app's own authorization for `ctx.auth.principal`.
  Scopes narrow what a person can reach; they never widen it.
- Put `express.json()` (or any JSON body parser) before the mount, or let mcp21 read the body
  bounded by `maxBodyBytes`.
- Persist audit events somewhere the person can see their own history.
- Wire `disabled()` to a real kill switch (env var, feature flag) so the endpoint can be turned
  off without a deploy.
- Serve over HTTPS only; a bearer token is a password.

## Development

```sh
npm run typecheck   # tsc --noEmit
npm test            # vitest, real http.createServer + Express + SDK Client
npm run build       # tsc -> dist/ (ESM + .d.ts)
```

Copyright © 2026 OMJ 21. Licensed to Roof-ER apps; not open source. See LICENSE.
